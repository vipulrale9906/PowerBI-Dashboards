<!-- For more projects: Visit codeastro.com  -->
<?php
error_reporting(1);
session_start();
include("dbcon.php");
if(isset($_SESSION['user_session'])){
  
  $invoice_number="CA-".invoice_number();
	header("location:home.php?invoice_number=$invoice_number");
}

   if(isset($_POST['submit'])){  //******Login Form*******
  $username =$_POST['username'];

  $password = $_POST['password'];

  $password = sha1($password);

  $select_sql = "SELECT * FROM users ";

  $select_query = mysqli_query($con,$select_sql);
   
  if($select_query){

  	while ($row =mysqli_fetch_array($select_query)) {
  		$s_username = $row['user_name'];
  		$s_password = $row['password'];
  	}
  }

 if($s_username == $username && $s_password == $password){
          
         $_SESSION['user_session'] = $s_username;
         $invoice_number="CA-".invoice_number();
 	       header("location:home.php?invoice_number=$invoice_number");


 }else{
 	  	    $error_msg = "<center><font color='red'>Login Failed</font></center>";
 }

}                  //******Login Form*******

  function invoice_number(){   //********Outputting Random Number For Invoice Number********

    $chars = "09302909209300923";

    srand((double)microtime()*1000000);

    $i = 1;

    $pass = '';

    while($i <=7){

      $num  = rand()%10;
      $tmp  = substr($chars, $num,1);
      $pass = $pass.$tmp;
      $i++;
    }
    return $pass;
                        //********Outputting Random Number For Invoice Number********
  }                       
?>

<!DOCTYPE html>
<html>
<!DOCTYPE html>
<html>
<head>
<!-- For more projects: Visit codeastro.com  -->
	<title>Medical Management System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <style>
/* Apply background image with a light blur effect */
/* General Styles */
/* General Styles */
/* General Styles */
/* ===== GENERAL STYLES ===== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html, body {
    height: 100%;
    width: 100%;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
                url('background.jpg') no-repeat center center fixed;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
}

/* ===== MAIN CONTAINER ===== */
.center-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
}

.content {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 30px;
    width: 90%;
    max-width: 400px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    text-align: center;
    animation: fadeIn 0.8s ease-in-out;
}

/* ===== HEADING & ICON ===== */
.fa-hospital {
    font-size: 60px;
    color: #2ecc71;
    margin-bottom: 15px;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1 {
    color: #2ecc71;
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 25px;
    letter-spacing: 1px;
    animation: slideDown 0.8s ease;
}

/* ===== FORM STYLING ===== */
form {
    width: 100%;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

td {
    padding: 8px 0;
}

label {
    color: #34495e;
    font-weight: 600;
    display: flex;
    align-items: center;
    font-size: 14px;
}

label i {
    margin-right: 8px;
    color: #2ecc71;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s ease;
    background: #f9f9f9;
}

input[type="text"]:focus,
input[type="password"]:focus {
    border-color: #2ecc71;
    background: #fff;
    box-shadow: 0 0 0 3px rgba(46, 204, 113, 0.2);
    outline: none;
}

/* ===== BUTTON STYLING ===== */
.btn-success {
    background: linear-gradient(135deg, #2ecc71, #27ae60);
    color: white;
    border: none;
    padding: 14px;
    width: 100%;
    font-size: 16px;
    font-weight: 600;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    margin-top: 10px;
}

.btn-success:hover {
    background: linear-gradient(135deg, #27ae60, #219653);
    transform: translateY(-2px);
    box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
}

.btn-success:active {
    transform: translateY(0);
}

/* ===== ERROR MESSAGE ===== */
.error {
    color: #e74c3c;
    font-size: 14px;
    margin-top: 10px;
    font-weight: 500;
}

/* ===== ANIMATIONS ===== */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideDown {
    from { 
        opacity: 0; 
        transform: translateY(-20px); 
    }
    to { 
        opacity: 1; 
        transform: translateY(0); 
    }
}

/* ===== RESPONSIVE DESIGN ===== */
@media (max-width: 500px) {
    .content {
        padding: 20px;
        width: 95%;
    }

    h1 {
        font-size: 20px;
    }

    .fa-hospital {
        font-size: 50px;
    }
}


    </style>
    
</head>
<body>
   
<div class="center-container">
        <div class="content">
        <center>
    <i class="fa fa-hospital" style="font-size: 50px; color: green;"></i>
    <h1 style="color: green; font-weight: bold; font-family: 'Arial', sans-serif; 
               animation: fadeIn 1.5s ease-in-out;">
        MEDICAL MANAGEMENT SYSTEM
    </h1>
</center>
            <form method="POST">
                <table>
                    <tr>
                    <td><label for="username" style="color: black; font-weight: bold;">
    <i class="fa fa-user"></i> Username 
</label></td>
                        <td><input type="text" name="username" placeholder="" required></td>
                    </tr>
                    <tr>
                    <td><label for="password" style="color: black; font-weight: bold;">
    <i class="fa fa-lock"></i> Password 
</label></td>
                        <td><input type="password" name="password" placeholder="" required></td>
                    </tr>
                </table>

                <input type="submit" name="submit" class="btn btn-success" value="Login">
                <?php echo $error_msg; ?>
            </form>
        </div>
    </div>
 
</body>
</html>
<!-- For more projects: Visit codeastro.com  -->